
# THIS FILE IS GENERATED FROM NUMPY SETUP.PY
short_version = '1.8.2'
version = '1.8.2'
full_version = '1.8.2'
git_revision = 'Unknown'
release = True

if not release:
    version = full_version
